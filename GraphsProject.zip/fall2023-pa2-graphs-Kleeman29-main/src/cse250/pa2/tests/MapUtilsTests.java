package cse250.pa2.tests;

import cse250.pa2.Edge;
import cse250.pa2.Intersection;
import cse250.pa2.MapUtils;
import cse250.pa2.StreetGraph;

import java.util.*;

import org.junit.Test;
import static org.junit.Assert.*;

public class MapUtilsTests {


    /**
     * A simple test that creates a three vertex graph shaped like a right triangle
     */
    @Test
    public void testSimpleGraph() {
        StreetGraph graph = new StreetGraph();
        Intersection i1 = new Intersection("Bottom Left", 0.0, 0.0);
        Intersection i2 = new Intersection("Bottom Right", 1.0, 0.0);
        Intersection i3 = new Intersection("Top Right", 1.0, 1.0);

        Edge e1 = new Edge(i1, i2, "Straight Right");
        Edge e2 = new Edge(i2, i3, "Straight Up");
        Edge e3 = new Edge(i1, i3, "Diagonal");

        graph.intersections.put("Bottom Left", i1);
        graph.intersections.put("Bottom Right", i2);
        graph.intersections.put("Top Right", i3);

        graph.edges.add(e1);
        graph.edges.add(e2);
        graph.edges.add(e3);

        Map<String, List<Edge>> adjLists = MapUtils.computeOutgoingEdges(graph);
        List<Edge> path1 = MapUtils.pathWithFewestIntersections(graph, adjLists, "Bottom Left", "Top Right");
        List<Edge> path2 = MapUtils.pathWithShortestDistance(graph, adjLists, "Bottom Left", "Top Right");

        assertTrue(adjLists.containsKey("Bottom Left"));
        assertEquals(2, adjLists.get("Bottom Left").size());

        assertEquals(1, path1.size());
        assertEquals(e3, path1.get(0));

        assertEquals(1, path2.size());
        assertEquals(e3, path2.get(0));
    }
    @Test
    public void SupermanTest() {
        StreetGraph g = new StreetGraph();
        Intersection s1 = new Intersection("B",4,0);
        Intersection s2 = new Intersection("L",2,6);
        Intersection s3 = new Intersection("TL",3,7);
        Intersection s4 = new Intersection("TR",5,7);
        Intersection s5 = new Intersection("R",7,6);

        Edge e1 = new Edge(s2,s1,"LB");
        Edge e2 = new Edge(s1,s5,"RB");
        Edge e3 = new Edge(s2,s3,"LTL");
        Edge e4 = new Edge(s3,s4,"S");
        Edge e5 = new Edge(s4,s5,"RTR");

        Edge e6 = new Edge(s5,s2,"RL");

        assertTrue(g!=null);

        g.intersections.put("B",s1);
        g.intersections.put("L",s2);
        g.intersections.put("TL",s3);
        g.intersections.put("TR",s4);
        g.intersections.put("R",s5);

        g.edges.add(e1);
        g.edges.add(e2);
        g.edges.add(e3);
        g.edges.add(e4);
        g.edges.add(e5);
        g.edges.add(e6);

        Map<String, List<Edge>> map = MapUtils.computeOutgoingEdges(g);

        assertTrue(map!=null);

        assertTrue(map.containsKey("B"));
        assertTrue(map.containsKey("L"));
        assertTrue(map.containsKey("TL"));
        assertTrue(map.containsKey("TR"));


        assertTrue(!(map.containsKey("LB")));
        assertTrue(!(map.containsKey("RB")));
        assertTrue(!(map.containsKey("LTL")));
        assertTrue(!(map.containsKey("RTR")));
        assertTrue(!(map.containsKey("S")));

        //assertTrue(map.get("L").size()==2);
       // assertTrue(map.get("B").size()==2);

        assertTrue(map.get("TL").contains(e4));

        List<Edge> fi = MapUtils.pathWithFewestIntersections(g,map,"L","R");
        List<Edge> fd = MapUtils.pathWithShortestDistance(g,map,"L","R");

        assertTrue(fi!=null);
        assertTrue(fd!=null);

        assertTrue(fi.size()!= fd.size());
        assertTrue(fi.size()==2);
        assertTrue(fd.size()==3);

        assertTrue(fi.contains(e1));
        assertTrue(fi.contains(e2));
        assertTrue(fi.get(0).streetName=="LB");
        assertTrue(fi.get(1).streetName=="RB");

        assertTrue(fd.contains(e3));
        assertTrue(fd.contains(e4));
        assertTrue(fd.contains(e5));




    }
    }

