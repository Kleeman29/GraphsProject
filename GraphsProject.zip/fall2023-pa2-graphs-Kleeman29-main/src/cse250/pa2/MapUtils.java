package cse250.pa2;

import java.util.*;
import java.util.stream.Collectors;

public class MapUtils {
    public static List<Edge> returnval;
    public static class pqInput{
        public Intersection i;
        public double len;
        private pqInput(Intersection i, double len){
            this.i=i;
            this.len=len;

        }
        public Intersection getInstance() {
            return i;
        }

        public double getLen() {
            return len;
        }
    }
    public static class comp implements Comparator<pqInput>{


        @Override
        public int compare(pqInput o1, pqInput o2) {
            return (int)(o1.getLen()*1000-o2.getLen()*1000);
        }


    }

    /**
     * Compute the outgoing links from each intersection in the graph.
     * @param    graph     The intersections and links for a map
     * @return             A lookup table of all outgoing edges for each intersection
     *
     * This function should run in O(graph.edges.size)
     */
    public static Map<String, List<Edge>> computeOutgoingEdges(StreetGraph graph) {
        if(graph==null){
            return new HashMap<>();
        }
        List<Edge> edges = graph.edges;
        Map<String, List<Edge>> map = new HashMap<>();
        if(edges.size()==0){
            return new HashMap<>();
        }
        for(int x = 0; x<edges.size();x++){
            String name = edges.get(x).from.id;
            if(map.containsKey(name)){
                map.get(name).add(edges.get(x));
            }
            else{
                map.put(name,new ArrayList<>());
                map.get(name).add(edges.get(x));
            }
        }

        return map;
    }
    /**
     * Compute the path between two intersections that passes through the fewest intersections.
     * @param    graph         The intersections and links for a map
     * @param    outgoingEdges A lookup table of all outgoing edges for each intersection
     * @param    from          The ID of the intersection to route from
     * @param    to            The ID of the intersection to route to
     * @return                 The shortest path needed to get from [[from]] to [[to]]
     *
     * This function should run in O(graph.edges.size + graph.intersections.size)
     */
    public static List<Edge> pathWithFewestIntersections(
            StreetGraph graph,
            Map<String, List<Edge>> outgoingEdges,
            String from,
            String to) {


            Queue<Intersection> todos = new LinkedList<>();
            Map<Intersection,Edge> map = new HashMap<>();
            Intersection v = graph.intersections.get(from);
            List<Intersection> visited = new ArrayList<>();
            List<Edge> explored = new ArrayList<>();
            visited.add(v);
            todos.add(v);
            while(!todos.isEmpty()) {
                Intersection i = todos.poll();
                if(outgoingEdges.containsKey(i.id)){
                List<Edge> edges = outgoingEdges.get(i.id);
                for (Edge e : edges) {
                    if (!explored.contains(e)) {
                        Intersection in = e.to;
                        if (in.id.equals(to)) {
                            map.put(in, e);
                            todos = new LinkedList<>();
                            break;
                        }
                        if (!visited.contains(in)) {
                            visited.add(in);

                            map.put(in, e);
                            todos.add(in);

                        }
                        explored.add(e);

                    }

                }}
            }


            Intersection i = graph.intersections.get(to);
            returnval = new ArrayList<>();
            boolean x = true;
                while(x){
                    Edge e = map.get(i);
                    i=e.from;
                    returnval.add(e);
                    if(i.id.equals(from)){
                        x=false;
                    }


                }
                Collections.reverse(returnval);



                return returnval;
            }









    /**
     * Compute the path between two intersections that has the shortest total distance.
     * @param    graph         The intersections and streets for a map
     * @param    outgoingEdges A lookup table of all outgoing edges for each intersection
     * @param    from          The ID of the intersection to route from
     * @param    to            The ID of the intersection to route to
     * @return                 The shortest path needed to get from [[from]] to [[to]]
     *
     * This function should run in O(graph.edges.size * log(graph.intersections.size))
     */
    public static List<Edge> pathWithShortestDistance(
            StreetGraph graph,
            Map<String, List<Edge>> outgoingEdges,
            String from,
            String to) {

        comp c = new comp();
        PriorityQueue<pqInput> todos = new PriorityQueue<pqInput>(c);
        Map<Intersection,edgewl> map = new HashMap<>();
        Intersection v = graph.intersections.get(from);
        List<Intersection> visited = new ArrayList<>();
        List<Edge> explored = new ArrayList<>();
        pqInput p = new pqInput(v,0);
        todos.add(p);

        while(!todos.isEmpty()) {
            pqInput td = todos.poll();
            Intersection i = td.getInstance();
            visited.add(i);
            if (i.id.equals(to)) {

                todos = new PriorityQueue<>();
                break;
            }
            if(outgoingEdges.containsKey(i.id)){
            List<Edge> edges = outgoingEdges.get(i.id);
            for (Edge e : edges) {
                if (!explored.contains(e)) {
                    Intersection in = e.to;

                    if (!visited.contains(in)) {

                        double len = e.getDistance();
                        pqInput pq = new pqInput(in, td.getLen()+len);
                        edgewl ed = new edgewl(e,td.getLen()+len);
                            if(map.containsKey(in)){
                                if(map.get(in).dist>td.getLen()+len){
                                    map.put(in,ed);
                                }
                            }
                            else {
                                map.put(in, ed);
                            }
                        todos.add(pq);

                    }
                    explored.add(e);

                }

            }}
        }


        Intersection i = graph.intersections.get(to);
        returnval = new ArrayList<>();
        boolean x = true;

        while(x){
            Edge e = map.get(i).e;
            i=e.from;
            returnval.add(e);
            if(i.id.equals(from)){
                x=false;
            }


        }
        Collections.reverse(returnval);
        return returnval;
    }
    private static class edgewl{
        public Edge e;
        public double dist;
        private edgewl(Edge e, double dist){
            this.e=e;
            this.dist=dist;
        }


    }

    /**
     * Generate a human-readable name for an intersection
     */
    public static String nameOfIntersection(String id, Map<String, List<Edge>> outgoingEdges) {
        List<String> streetNames = outgoingEdges.get(id).stream()
                .map(edge -> edge.streetName)
                .distinct()
                .collect(Collectors.toList());

        switch (streetNames.size()) {
            case 0:
                return id + " @ Empty Intersection";
            case 1:
                return id + " @ " + streetNames.get(0);
            case 2:
                return id + " @ " + streetNames.get(0) + " and " + streetNames.get(1);
            default:
                String allButLast = String.join(", ", streetNames.subList(0, streetNames.size() - 1));
                return id + " @ " + allButLast + ", and " + streetNames.get(streetNames.size() - 1);
        }
    }
}

