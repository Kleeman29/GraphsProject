#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#include "life.h"

/* Be sure to read life.h and the other given source files to understand
 * what they provide and how they fit together.  You don't have to
 * understand all of the code, but you should understand how to call
 * parse_life() and clearterm().
 */

/* This is where your program will start.  You should make sure that it
 * is capable of accepting either one or two arguments; the first
 * argument (which is required) is a starting state in one of the Life
 * formats supported by parse_life(), and the second (which is optional)
 * is a number of generations to run before printing output and stopping.
 *
 * The autograder will always call your program with two arguments.  The
 * one-argument format (as described in the handout) is for your own
 * benefit!
 */
void printgrid(char **grid);
int numNeighbors(char **grid,int y, int x);
void makeMagic(int gens, char **grid, char *f);
char **copy(char **grid, char **grid2);

int main(int argc, char *argv[])
{
  
  char **grid = parse_life(argv[1]);
  if(argc>3){
    printf("Error");
    return -1;
  }
  int gens=0;
  for(int x = 0; argv[2][x]!='\0';x++){
    gens=gens*10;
     gens = gens+ argv[2][x]-'0';
    
  }
  if(grid==NULL){
    printf("Error");
    return -1;
  }
  else{
    makeMagic(gens,grid,argv[1]);
  }
  
    return 0;
}

void printgrid(char **grid){
  for(int y= 0; y<24;y++){
    for(int x=0; x<80;x++){
      putchar(grid[y][x]);
    }
    putchar('\n');

  }
}
char **copy(char **grid, char **grid2){
  for(int y = 0; y<24; y++){
    for(int x =0; x<80; x++){
      grid2[y][x]=grid[y][x];

    }

  }

  return grid2;
}


void makeMagic(int gens, char **grid,char *f){
      char **grid2=parse_life(f);
  for(int g = 0; g<gens; g++){
    grid2 = copy(grid,grid2);
    for(int y = 0; y<24; y++){
      for(int x=0; x<80; x++){
	int numn = numNeighbors(grid,y,x);
	if(grid[y][x]==' '&& numn==3){
	  grid2[y][x]='X';
	  
	}
	
	  if(numn<2){
	    grid2[y][x]=' ';
	  }
	  if(numn>3){
	    grid2[y][x]=' ';
	  }
	  
	  
	

      }


    }
    grid=copy(grid2,grid); 
  }
  printgrid(grid);
}







int numNeighbors(char **grid,int y, int x){
  int num=0;
  bool top = false;
  bool bot = false;
  bool rit = false;
  bool lef = false;
  if(y==0){
    top=true;
  }
  if(x==0){
    lef=true;
  }
  if(y==23){
    bot = true;
  }
  if(x==79){
    rit=true;
  }
  
    if(top==true && rit==true){
      if(grid[y+1][x]=='X'){
	num++;
      }
      if(grid[y+1][x-1]=='X'){
	num++;
      }
      if(grid[y][x-1]=='X'){
	num++;
      }
      return num;
      
    }
    if(top&&lef){
      if(grid[y+1][x]=='X'){
	num++;
      }
      if(grid[y+1][x+1]=='X'){
	num++;
      }
      if(grid[y][x+1]=='X'){
	num++;
      }
      return num;

    }
    if(top==true){
      if(grid[y+1][x]=='X'){
	num++;
      }
      if(grid[y+1][x+1]=='X'){
	num++;
      }
      if(grid[y+1][x-1]=='X'){
	num++;
      }
      if(grid[y][x+1]=='X'){
	num++;
      }
      if(grid[y][x-1]=='X'){
	num++;
      }
      return num;
    }
    if(bot&&rit){
      if(grid[y-1][x]=='X'){
	num++;
      }
      if(grid[y-1][x-1]=='X'){
	num++;
      }
      if(grid[y][x-1]=='X'){
	num++;
      }
      return num;

    }
    if(bot&&lef){
      if(grid[y-1][x]=='X'){
	num++;
      }
      if(grid[y-1][x+1]=='X'){
	num++;
      }
      if(grid[y][x+1]=='X'){
	num++;
      }
      return num;

    }
    if(bot){
      if(grid[y-1][x]=='X'){
	num++;
      }
      if(grid[y-1][x-1]=='X'){
	num++;
      }
      if(grid[y-1][x+1]=='X'){
	num++;
      }
      if(grid[y][x+1]=='X'){
	num++;
      }
      if(grid[y][x-1]=='X'){
	num++;
      }
      return num;
      

    }
    if(rit){
      if(grid[y-1][x]=='X'){
	num++;
      }
      if(grid[y-1][x-1]=='X'){
	num++;
      }
      if(grid[y][x-1]=='X'){
	num++;
      }
      if(grid[y+1][x-1]=='X'){
	num++;
      }
      if(grid[y+1][x]=='X'){
	num++;
      }
      return num;
      

    }
    if(lef){
      if(grid[y-1][x]=='X'){
	num++;
      }
      if(grid[y-1][x+1]=='X'){
	num++;
      }
      if(grid[y][x+1]=='X'){
	num++;
      }
      if(grid[y+1][x+1]=='X'){
	num++;
      }
      if(grid[y+1][x]=='X'){
	num++;
      }
      return num;

    }

  
 
    if(grid[y+1][x]=='X'){
      num++;
    }
    if(grid[y+1][x+1]=='X'){
      num++;
    }
    if(grid[y+1][x-1]=='X'){
      num++;
    }
    if(grid[y-1][x]=='X'){
      num++;
    }
    if(grid[y-1][x+1]=='X'){
      num++;
    }
    if(grid[y-1][x-1]=='X'){
      num++;
    }
    if(grid[y][x+1]=='X'){
      num++;
    }
    if(grid[y][x-1]=='X'){
      num++;
    }
    return num;
}
