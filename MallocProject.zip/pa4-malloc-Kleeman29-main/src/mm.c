#include <string.h>
#include <stdio.h>
#include <unistd.h>
/* The standard allocator interface from stdlib.h.  These are the
 * functions you must implement, more information on each function is
 * found below. They are declared here in case you want to use one
 * function in the implementation of another. */
void *malloc(size_t size);
void free(void *ptr);
void *calloc(size_t nmemb, size_t size);
void *realloc(void *ptr, size_t size);
static void instantiatefreel();
static void makeblocks(int y);

/* When requesting memory from the OS using sbrk(), request it in
 * increments of CHUNK_SIZE. */
#define CHUNK_SIZE (1<<12)
static int freed;

struct block{
  int* header;
  struct block* next;
};

static struct block* freelist[13];

/*
 * This function, defined in bulk.c, allocates a contiguous memory
 * region of at least size bytes.  It MAY NOT BE USED as the allocator
 * for pool-allocated regions.  Memory allocated using bulk_alloc()
 * must be freed by bulk_free().
 *
 * This function will return NULL on failure.
 */
extern void *bulk_alloc(size_t size);

/*
 * This function is also defined in bulk.c, and it frees an allocation
 * created with bulk_alloc().  Note that the pointer passed to this
 * function MUST have been returned by bulk_alloc(), and the size MUST
 * be the same as the size passed to bulk_alloc() when that memory was
 * allocated.  Any other usage is likely to fail, and may crash your
 * program.
 *
 * Passing incorrect arguments to this function will result in an
 * error message notifying you of this mistake.
 */
extern void bulk_free(void *ptr, size_t size);

/*
 * This function computes the log base 2 of the allocation block size
 * for a given allocation.  To find the allocation block size from the
 * result of this function, use 1 << block_index(x).
 *
 * This function ALREADY ACCOUNTS FOR both padding and the size of the
 * header.
 *
 * Note that its results are NOT meaningful for any
 * size > 4088!
 *
 * You do NOT need to understand how this function works.  If you are
 * curious, see the gcc info page and search for __builtin_clz; it
 * basically counts the number of leading binary zeroes in the value
 * passed as its argument.
 */
static inline __attribute__((unused)) int block_index(size_t x) {
    if (x <= 8) {
        return 5;
    } else {
        return 32 - __builtin_clz((unsigned int)x + 7);
    }
}

/*
 * You must implement malloc().  Your implementation of malloc() must be
 * the multi-pool allocator described in the project handout.
 */
void *malloc(size_t size) {
  if(size==0){
    return NULL;
  }
  if(size>CHUNK_SIZE-8){
    void *p= bulk_alloc(size+8);
    *(int *)p = size;
    return p+8;
  }
  else{
    if(freed!=1){
      instantiatefreel();
      freed=1;
    }
    int y = block_index(size);
    if(y<5){
      y=5;
    }
    if(freelist[y]==NULL){
     
      makeblocks(y);


    }
    
      void *r = (void *)freelist[y];
      freelist[y]=freelist[y]->next;
      *(int *)(r-8)=*(int *)(r-8) | 1;
      return r;
    
    



  }
  
  
}
static void makeblocks(int y){
  void *p = sbrk(CHUNK_SIZE);
  int x = 2;
  for(int z = 0;z<y-1;z++){
    x=x*2;
  }
  for(int z =0;z<CHUNK_SIZE;z+=x){
    *(int *)p = x;
    p=p+8;
    struct block *b = (struct block *)p;
    b->header= (int *)(p-8);
    b->next = freelist[y];
    freelist[y]=b;
    p=p+(x-8);
    
    
}
  
  

}

static void instantiatefreel(){
  void *p = sbrk(CHUNK_SIZE);
  *freelist=p;
  for(int x =0; x<13;x++){
    freelist[x]=NULL;
  }
  

}

/*
 * You must also implement calloc().  It should create allocations
 * compatible with those created by malloc().  In particular, any
 * allocations of a total size <= 4088 bytes must be pool allocated,
 * while larger allocations must use the bulk allocator.
 *
 * calloc() (see man 3 calloc) returns a cleared allocation large enough
 * to hold nmemb elements of size size.  It is cleared by setting every
 * byte of the allocation to 0.  You should use the function memset()
 * for this (see man 3 memset).
 */
void *calloc(size_t nmemb, size_t size) {
  if(size==0){
    return NULL;
  }
  void *ptr;
  if(nmemb*size>CHUNK_SIZE-8){
    ptr = bulk_alloc(nmemb * size);
  }
  else{
    ptr = malloc(nmemb * size);
  }
    memset(ptr, 0, nmemb * size);
    return ptr;
}

/*
 * You must also implement realloc().  It should create allocations
 * compatible with those created by malloc(), honoring the pool
 * alocation and bulk allocation rules.  It must move data from the
 * previously-allocated block to the newly-allocated block if it cannot
 * resize the given block directly.  See man 3 realloc for more
 * information on what this means.
 *
 * It is not possible to implement realloc() using bulk_alloc() without
 * additional metadata, so the given code is NOT a working
 * implementation!
 */
void *realloc(void *ptr, size_t size) {
  if(size==0){
    return NULL;
  }
  void *ptr2 = malloc(size);
  if(ptr==NULL){
    return ptr2;
  }
  int size2 = *(int *)(ptr-8);
  if((size2 & 1)== 0){
    return NULL;
  }
  size2=size2>>1;
  size2=size2<<1;
  int s = size2;
  free(ptr);
  if(size<size2){
    s=size;
  }
  for(int x = 0; x<s;x++){
    *(char *)(ptr2+x)=*(char *)(ptr+x);

  }
  return ptr2;
  
}

/*
 * You should implement a free() that can successfully free a region of
 * memory allocated by any of the above allocation routines, whether it
 * is a pool- or bulk-allocated region.
 *
 * The given implementation does nothing.
 */
void free(void *ptr) {
  if(ptr==NULL){
    return;
  }
  int s = *(int *)(ptr-8);
   if((s&1)==0){
    return;
  }
  if(s>CHUNK_SIZE-8){
    printf("%d",s);
    bulk_free(ptr-8,s);
    return;
  }
 
  
  *(int *)(ptr-8)=s-1;
  int y = block_index(s);
 struct block *b = (struct block *)(ptr);
 b->header=(int *)(ptr-8);
  b->next=freelist[y];
  freelist[y]=b;
  
  
    return;

}
